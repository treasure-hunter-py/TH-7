# from os import name, read
import pathlib
import csv
import os
import json

def log_data(user, action):
    print(user, action)
    with open(pathlib.Path(__file__).parent.joinpath('LOG').joinpath('ATM_LOG.json'), 'a') as json_file:
        print(user, action) 
        temp_dikt = {user: action}
        json_file.write(json.dumps(temp_dikt))

    

def cln():
    # os.system('cls||clear')
    pass

def start_main():
    pass

def balance_add(user_id): #prod
    cln()
    temp_many = 0
    with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'r') as many_file: 
        temp_many = int(many_file.read())

    temp = int(input('n mach ? '))
    log_data(user_id, f'add {temp}, summ {temp_many}')
    with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'w') as many_file: 
        many_file.write(str(temp_many+temp))
         
def balance_checkr(user_id):    #prod
    cln()
    temp_many = 0
    with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'r') as many_file_temp:
            temp_many = many_file_temp.read()
            print(f'you deposut {temp_many} $')

def user_menu(menu_page):
    if menu_page == '1':
        print('____________________')
        print('balance check 1 ')
        print('balance change 2 ')
        print('balance exit 3 ')
        print('--------------------')
    # if menu_page == '2'
    return

def validator(user_name = 0,user_password = 0): #prod
    with open(pathlib.Path(__file__).parent.joinpath('db').joinpath('db.txt'), 'r') as validator_file:
        #print(validator_file.read())
        temp_file = csv.DictReader(validator_file)
        for dict_user in temp_file:
            if user_name == dict_user['name']:
                if user_password == dict_user['password']:
                    return dict_user['name']
                else:
                    print('error password')
            else:
                print('user is not found... ')

def user_akaunt(user_name,user_password):
    while True:
        flag = validator(user_name,user_password)
        if flag != None:
            user_menu('1')
            user_option = input('_ ')
            if user_option == '1':
                log_data(user_name, 'loock')
                balance_checkr(user_name)
            elif user_option == '2':
                balance_add(user_name)
            elif user_option == '3':
                log_data(user_name, 'exit')
                cln()
                return



user_akaunt('user_1','1111')
print('out')

def start():
    pass

    
